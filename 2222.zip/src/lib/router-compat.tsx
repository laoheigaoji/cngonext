"use client";

import NextLink from "next/link";
import { usePathname, useRouter, useSearchParams, useParams as useNextParams } from "next/navigation";
import React, { useMemo } from "react";

// Compatibility Link: maps react-router-dom's `to` prop to Next.js `href`
export const Link = React.forwardRef<HTMLAnchorElement, any>(function Link(
  { to, href, replace: replaceProp, ...rest },
  ref
) {
  const targetHref = to || href;
  return <NextLink ref={ref} href={targetHref} {...rest} />;
});

// Simple compatibility for react-router-dom in Next.js
export const useLocation = () => {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  
  return useMemo(() => ({
    pathname,
    search: searchParams?.toString() ? `?${searchParams.toString()}` : "",
    hash: "", // Next.js doesn't easily expose hash on server components, but this is a client hook
    state: null,
    key: "default"
  }), [pathname, searchParams]);
};

export const useNavigate = () => {
  const router = useRouter();
  
  return useMemo(() => {
    return (to: any, options?: { replace?: boolean, state?: any }) => {
      if (options?.replace) {
        router.replace(to);
      } else {
        router.push(to);
      }
    };
  }, [router]);
};

export const useParams = <T extends Record<string, string | string[]> = Record<string, string | string[]>>() => {
  return useNextParams() as T; 
};

// We will also need a special Navigate component
export const Navigate = ({ to, replace }: { to: string, replace?: boolean }) => {
  const router = useRouter();
  React.useEffect(() => {
    if (replace) {
      router.replace(to);
    } else {
      router.push(to);
    }
  }, [to, replace, router]);
  return null;
};
