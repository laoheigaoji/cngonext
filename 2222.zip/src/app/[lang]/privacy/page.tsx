"use client";

import PrivacyPolicy from "@/app-views/PrivacyPolicy";

export default function Page() {
  return <PrivacyPolicy />;
}
