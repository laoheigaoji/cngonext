"use client";

import React, { useEffect } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguage, Language } from "@/context/LanguageContext";
import { useParams } from "next/navigation";

export default function LangLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { lang } = useParams();
  const { setLanguage } = useLanguage();

  useEffect(() => {
    const langMap: Record<string, string> = {
      cn: 'zh',
      tw: 'tw',
      en: 'en',
      ja: 'ja',
      ko: 'ko',
      ru: 'ru',
      fr: 'fr',
      es: 'es',
      de: 'de',
      it: 'it'
    };
    const targetLang = langMap[lang as string] || 'en';
    setLanguage(targetLang as Language);
  }, [lang, setLanguage]);

  return (
    <div className="min-h-screen flex flex-col font-sans bg-[#f7f7f7] text-gray-800">
      <Navbar />
      <main className="flex-grow flex flex-col">
        {children}
      </main>
      <Footer />
    </div>
  );
}
