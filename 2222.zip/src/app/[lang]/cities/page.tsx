"use client";

import Cities from "@/app-views/Cities";

export default function Page() {
  return <Cities />;
}
