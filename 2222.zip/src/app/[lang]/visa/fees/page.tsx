"use client";

import VisaFees from "@/app-views/visa/VisaFees";

export default function Page() {
  return <VisaFees />;
}
