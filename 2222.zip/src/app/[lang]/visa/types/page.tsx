"use client";

import VisaTypes from "@/app-views/visa/VisaTypes";

export default function Page() {
  return <VisaTypes />;
}
