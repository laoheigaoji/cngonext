"use client";

import Apps from "@/app-views/Apps";

export default function Page() {
  return <Apps />;
}
