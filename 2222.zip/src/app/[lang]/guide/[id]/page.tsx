"use client";

import GuideDetail from "@/app-views/guide/GuideDetail";

export default function Page() {
  return <GuideDetail />;
}
