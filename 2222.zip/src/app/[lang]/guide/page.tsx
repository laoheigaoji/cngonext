"use client";

import Guide from "@/app-views/Guide";

export default function Page() {
  return <Guide />;
}
