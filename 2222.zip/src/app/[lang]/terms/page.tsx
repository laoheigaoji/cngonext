"use client";

import TermsOfService from "@/app-views/TermsOfService";

export default function Page() {
  return <TermsOfService />;
}
