"use client";

import GuideList from "@/app-views/guide/GuideList";

export default function Page() {
  return <GuideList />;
}
