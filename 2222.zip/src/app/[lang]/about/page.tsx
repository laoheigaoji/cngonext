"use client";

import AboutUs from "@/app-views/AboutUs";

export default function Page() {
  return <AboutUs />;
}
