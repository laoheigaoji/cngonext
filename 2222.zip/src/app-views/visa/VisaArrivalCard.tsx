export { default } from "@/pages/visa/VisaArrivalCard";
