export { default } from "@/pages/visa/VisaDownloads";
