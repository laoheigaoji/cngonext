export { default } from "@/pages/visa/VisaFees";
