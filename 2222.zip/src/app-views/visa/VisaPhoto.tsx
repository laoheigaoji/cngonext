export { default } from "@/pages/visa/VisaPhoto";
