export { default } from "@/pages/visa/VisaTypes";
