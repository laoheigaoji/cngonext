export { default } from "@/pages/guide/GuideDetail";
