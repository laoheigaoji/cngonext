export { default } from "@/pages/city/CityDetail";
