export { default } from "@/pages/tools/ZodiacCalculator";
