export { default } from "@/pages/tools/NameGenerator";
