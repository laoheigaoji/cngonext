export { default } from "@/pages/tools/PinyinSegmentation";
