export { default } from "@/pages/tools/MenuTranslator";
