export { default } from "@/pages/tools/CharacterCounter";
